import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["packages/*/src/**/*.test.ts", "workers/*/src/**/*.test.ts"],
    environment: "node",
  },
});
